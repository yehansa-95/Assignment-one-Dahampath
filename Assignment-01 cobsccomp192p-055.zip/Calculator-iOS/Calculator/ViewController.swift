//
//  ViewController.swift
//  Calculator
//
//  Created by Kasun on 01/06/21.
//  Copyright © 2021 Kasun. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    

}

